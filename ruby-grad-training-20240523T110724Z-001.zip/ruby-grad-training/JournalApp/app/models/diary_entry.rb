class DiaryEntry < ApplicationRecord
end
