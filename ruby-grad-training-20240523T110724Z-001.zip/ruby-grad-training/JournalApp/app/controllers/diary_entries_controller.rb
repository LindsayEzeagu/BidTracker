class DiaryEntriesController < ApplicationController
  def index
    @diary_entries = DiaryEntry.all
  end

  def new
    @diary_entry = DiaryEntry.new()
  end

  def create
      @diary_entry = DiaryEntry.new(diary_entry_params)
      if @diary_entry.save
        redirect_to root_url
    else
      render :new
    end
  end
  
private

  def diary_entry_params
      params.require(:diary_entry).permit(:name)
  end
end

