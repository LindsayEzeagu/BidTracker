class ApplicationController < ActionController::Base
end

class ApplicationController < ActionController::Base

      render html: "Hello World!"
  end
