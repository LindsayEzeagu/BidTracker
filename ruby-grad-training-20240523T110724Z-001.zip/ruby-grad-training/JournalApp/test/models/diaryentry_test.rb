require "test_helper"

class DiaryentryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
