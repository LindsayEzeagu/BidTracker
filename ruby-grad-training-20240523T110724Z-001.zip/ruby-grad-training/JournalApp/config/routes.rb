Rails.application.routes.draw do
  root 'diary_entries#index'
  resources :diary_entries, only: [:create, :new]
end
